#pragma once

#include <stdio.h>
#include <assert.h>
#include <iostream>
#include <vector>
#include <list>
#include <queue>
#include <tuple>
#include <unordered_set>
#include <unordered_map>
#include <memory>
#include <functional>
#include <limits>

#define PI 3.14159265358979323846
#define _USE_MATH_DEFINES
#define DBL_EPSILON numeric_limits<double>::min()

#include <cmath>
#include <cstdlib>